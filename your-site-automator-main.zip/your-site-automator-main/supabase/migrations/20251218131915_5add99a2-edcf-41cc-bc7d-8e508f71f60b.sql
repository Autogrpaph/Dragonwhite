-- Enable realtime for teams table
ALTER PUBLICATION supabase_realtime ADD TABLE public.teams;