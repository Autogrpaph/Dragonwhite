
-- Add 'problematic' to the admin_task_status enum
ALTER TYPE public.admin_task_status ADD VALUE 'problematic';
